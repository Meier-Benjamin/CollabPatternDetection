import csv
from collections import defaultdict
import customtkinter as ctk
from tkinter import filedialog, messagebox, ttk, font
from PIL import ImageTk
import pandas as pd
import pm4py
from pm4py.visualization.petri_net import visualizer as pn_visualizer
from pm4py.visualization.petri_net.common import visualize as pn_visualize
import plotly.express as px
import random
import threading

# Installation of required libraries:

# pip install Pillow pandas pm4py plotly customtkinter

# Dictionary containing the ranking between patterns:
PATTERN_RANK = {
    'Collaboration': 1,
    'Cooperation': 2,
    'Synchronized': 3,
    'Coexistence': 4
}

def read_event_log(file_path):
    # Create list of events from event log (from CSV file)
    events = []
    with open(file_path, 'r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            events.append({
                'case_id': row['case_id'],
                'activity': row['activity'],
                'start_timestamp': pd.to_datetime(row['start_timestamp']),
                'end_timestamp': pd.to_datetime(row['end_timestamp']) if row['end_timestamp'] else None,
                'resource': row['resource']
            })
    return events

def update_pattern(patterns, activity, pattern, contributing_activities, contributing_activity):
    # Check if rank of new pattern is higher than current patterns rank, update accordingly
    if activity in patterns:
        # If there already exists a pattern for this activity
        current_pattern = patterns[activity]
        # Check if rank of new pattern is higher
        if PATTERN_RANK[pattern] < PATTERN_RANK[current_pattern]:
            patterns[activity] = pattern
            contributing_activities[activity] = [contributing_activity]
        elif PATTERN_RANK[pattern] == PATTERN_RANK[current_pattern]:
            contributing_activities[activity].append(contributing_activity)
    else:
        # If no pattern exists yet for this activity
        patterns[activity] = pattern
        contributing_activities[activity] = [contributing_activity]

def find_patterns_in_case(case_id, case_events, threshold_percentage=30):
    patterns = {}
    # Create a list of contributing activities for each activity
    contributing_activities = defaultdict(list)
    # Filter out events that don't have an end timestamp or have the same start and end timestamp (System events)
    case_events = [event for event in case_events if event['end_timestamp'] and event['start_timestamp'] != event['end_timestamp']]
    # Calculate the mean length of activities in the case
    mean_duration = pd.Series([(event['end_timestamp'] - event['start_timestamp']).total_seconds() for event in case_events]).mean()
    threshold = pd.Timedelta(seconds=(mean_duration * threshold_percentage / 100))
    # Get a list of unique resources (actors) from the case events
    actors = list(set(event['resource'] for event in case_events))

    if len(actors) == 1:
        # Base case: If only one actor present (System events do not count), pattern is Coexistence for every activity of this case.
        for event in case_events:
            update_pattern(patterns, event['activity'], 'Coexistence', contributing_activities, event['activity'])
    else:
        # For each event of the case:
        for i in range(len(case_events)):
            for j in range(i + 1, len(case_events)):
                # For each combination of events in the case:
                a, b = case_events[i], case_events[j]
                # Check for Collaboration group (1:n) (a = long activity, b= one of the short activities)
                if is_collaboration_group(case_events, a, b, threshold):
                    print(f"Case {case_id}: Collaboration Group detected between {a['activity']} and {b['activity']}")
                    update_pattern(patterns, a['activity'], 'Collaboration', contributing_activities, b['activity'])
                    update_pattern(patterns, b['activity'], 'Collaboration', contributing_activities, a['activity'])
                # Check for collaboration (1:1)
                elif is_collaboration(a, b, threshold):
                    print(f"Case {case_id}: Collaboration detected between {a['activity']} and {b['activity']}")
                    update_pattern(patterns, a['activity'], 'Collaboration', contributing_activities, b['activity'])
                    update_pattern(patterns, b['activity'], 'Collaboration', contributing_activities, a['activity'])
                # Check for Cooperation (1:1)
                elif is_cooperation(a, b, threshold):
                    print(f"Case {case_id}: Cooperation detected between {a['activity']} and {b['activity']}")
                    update_pattern(patterns, a['activity'], 'Cooperation', contributing_activities, b['activity'])
                    update_pattern(patterns, b['activity'], 'Cooperation', contributing_activities, a['activity'])
                # Check for Synchronized (1:1)
                elif is_synchronized(a, b, threshold):
                    print(f"Case {case_id}: Synchronized detected between {a['activity']} and {b['activity']}")
                    update_pattern(patterns, a['activity'], 'Synchronized', contributing_activities, b['activity'])
                    update_pattern(patterns, b['activity'], 'Synchronized', contributing_activities, a['activity'])

    return case_id, patterns, contributing_activities, threshold

def is_synchronized(a, b, threshold):
    # If no overlap or short overlap occurs between events, even when they are performed by the same actor.
    # Function checks if event a starts only after event b has ended and there is no overlap, including threshold.
    if b['start_timestamp'] > a['end_timestamp'] + threshold or a['start_timestamp'] > b['end_timestamp'] + threshold:
        return True
    return False

def is_collaboration(a, b, threshold):
    # If resources are the same, no collaboration occurs between them.
    if a['resource'] == b['resource']:
        return False
    # If overlap occurs (also within threshold), pattern = collaboration.
    if abs(a['start_timestamp'] - b['start_timestamp']) <= threshold and abs(a['end_timestamp'] - b['end_timestamp']) <= threshold:
        return True
    return False

def is_collaboration_group(case_events, a, b, threshold):
    overlap_start = max(a['start_timestamp'], b['start_timestamp'])
    overlap_end = min(a['end_timestamp'], b['end_timestamp'])
    
    # Check if activities actually overlap and if resources are different
    if a['resource'] == b['resource'] or overlap_start > overlap_end:
        return False
    # If b is the longer event, swap a and b. (simplifies rest of this function)
    if a['end_timestamp'] - a['start_timestamp'] < b['end_timestamp'] - b['start_timestamp']:
        a, b = b, a
    
    # If the end timestamp of b is later than the end timestamp of a + threshold, no collaboration occurs.
    # Necessary because otherwise collaboration would be classified if b begins during a and ends much later, and there are other activities c(,d...) that occur during a and have a similar end timestamp.
    if a['end_timestamp'] + threshold <= b['end_timestamp']:
        return False

    # Collect shorter activities of b's resource during and around a's duration
    shorter_activities = []
    for event in case_events:
        if event['resource'] != a['resource']:
            # Check if the event falls within the time window of a or the thresholds
            if (event['start_timestamp'] >= a['start_timestamp'] - threshold and
                event['end_timestamp'] <= a['end_timestamp'] + threshold):
                # Check if the duration of the event is shorter than the duration of a
                if (event['end_timestamp'] - event['start_timestamp']) <= (a['end_timestamp'] - a['start_timestamp']):
                    shorter_activities.append(event)

    # Check if the shorter activities exist:
    if shorter_activities:
        first_short_activity = min(shorter_activities, key=lambda x: x['start_timestamp'])
        last_short_activity = max(shorter_activities, key=lambda x: x['end_timestamp'])
        

        # Ensure the shorter activities are fully within the threshold period
        if (first_short_activity['start_timestamp'] <= (a['start_timestamp'] + threshold) and
            last_short_activity['end_timestamp'] >= (a['end_timestamp'] - threshold)):
            return True

    return False

def is_cooperation(a, b, threshold):
    # Check if resources are different
    if a['resource'] == b['resource']:
        return False
    # Check if Activities overlap.
    if (a['start_timestamp'] < b['start_timestamp'] < a['end_timestamp'] or
        a['start_timestamp'] < b['end_timestamp'] < a['end_timestamp'] or
        b['start_timestamp'] < a['start_timestamp'] < b['end_timestamp'] or
        b['start_timestamp'] < a['end_timestamp'] < b['end_timestamp']):
        return True
    return False


class CollaborationPatternApp:
    # GUI code
    def __init__(self, root):
        self.root = root
        self.root.title("Collaboration Pattern Classifier")

        self.frame = ctk.CTkFrame(root)
        self.frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        
        # Make the main frame expand with the window
        root.columnconfigure(0, weight=1)
        root.rowconfigure(0, weight=1)
        self.frame.columnconfigure(0, weight=1)
        self.frame.rowconfigure(4, weight=1)
        self.frame.rowconfigure(5, weight=1)
        self.frame.rowconfigure(7, weight=1)
        
        self.title_label = ctk.CTkLabel(self.frame, text="Collaborative Pattern Identification", font=("Arial", 16, "bold"))
        self.title_label.grid(row=0, column=0, padx=5, pady=5, sticky="w")

        self.help_button = ctk.CTkButton(self.frame, text="?", width=30, command=self.show_help)
        self.help_button.grid(row=0, column=2, padx=5, pady=5, sticky="e")

        self.threshold_label = ctk.CTkLabel(self.frame, text="Threshold (% of mean duration):", font=("Arial", 12))
        self.threshold_label.grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.threshold_label_ttp = self.create_tooltip(self.threshold_label, "Defines the threshold percentage of the mean activity duration used to determine Collaboration.")

        self.threshold_entry = ctk.CTkEntry(self.frame, font=("Arial", 12))
        self.threshold_entry.grid(row=2, column=0, padx=5, pady=5, sticky="w")
        self.threshold_entry_ttp = self.create_tooltip(self.threshold_entry, "Defines the threshold percentage of the mean activity duration used to determine Collaboration.")
        self.threshold_entry.insert(0, "30")  # Default value of 30%
        
        self.load_button = ctk.CTkButton(self.frame, text="Load Event Log", command=self.load_event_log, font=("Arial", 12))
        self.load_button.grid(row=3, column=0, padx=5, pady=5, sticky="w")
        self.load_button_ttp = self.create_tooltip(self.load_button, "Imports a .csv event log and discovers Collaborative patterns. Please set the Threshold value accordingly before loading the event log.")

        self.view_model_button = ctk.CTkButton(self.frame, text="View Process Model", command=self.display_petri_net, font=("Arial", 12))
        self.view_model_button.grid(row=4, column=0, padx=(5, 0), pady=5, sticky="w")
        self.view_model_button.grid_remove()  # Initially hidden
        self.view_model_button_ttp = self.create_tooltip(self.view_model_button, "Discovers and displays a process model using the Inductive Miner")

        self.analyze_variants_button = ctk.CTkButton(self.frame, text="Analyze Process Variants", command=self.analyze_process_variants, font=("Arial", 12))
        self.analyze_variants_button.grid(row=4, column=1, padx=(5, 0), pady=5, sticky="w")
        self.analyze_variants_button.grid_remove()  # Initially hidden
        self.analyze_variants_button_ttp = self.create_tooltip(self.analyze_variants_button, "Shows an overview over the existing process variants and which patterns were discovered in them")

        self.save_button = ctk.CTkButton(self.frame, text="Save as CSV", command=self.save_as_csv, font=("Arial", 12))
        self.save_button.grid(row=4, column=2, padx=(5, 0), pady=5, sticky="w")
        self.save_button.grid_remove()  # Initially hidden
        self.save_button_ttp = self.create_tooltip(self.save_button, "Saves the current list of cases and patterns as a CSV file")

        self.case_list_frame = ctk.CTkFrame(self.frame)
        self.case_list_frame.grid(row=5, column=0, columnspan=3, padx=5, pady=5, sticky="nsew")
        self.case_list_frame.grid_remove()  # Initially hidden
        
        # Make the case_list_frame expandable
        self.case_list_frame.columnconfigure(0, weight=1)
        self.case_list_frame.rowconfigure(0, weight=1)

        # Set the font for the Treeview
        style = ttk.Style()
        style.configure("Treeview", font=('Arial', 14))  # Set font size to 14 for Treeview items
        style.configure("Treeview.Heading", font=('Arial', 14, 'bold'))  # Set font size to 14 and bold for headings
        style.configure("Treeview", rowheight=25)  # Adjust the height of the Treeview rows if necessary

        self.case_list = ttk.Treeview(self.case_list_frame, columns=("Case ID", "Threshold", "Pattern"), show="headings", height=10, style="Treeview")
        self.case_list.heading("Case ID", text="Case ID")
        self.case_list.heading("Threshold", text="Threshold")
        self.case_list.heading("Pattern", text="Pattern")
        self.case_list.column("Case ID", width=160)  # Adjusted width
        self.case_list.column("Threshold", width=100)  # Adjusted width
        self.case_list.column("Pattern", width=500)  # Adjusted width
        self.case_list.bind("<<TreeviewSelect>>", self.on_case_select)
        self.case_list.grid(row=0, column=0, sticky="nsew")

        self.case_list_scroll_x = ctk.CTkScrollbar(self.case_list_frame, orientation="horizontal", command=self.case_list.xview)
        self.case_list_scroll_x.grid(row=1, column=0, sticky="ew")

        self.case_list_scroll_y = ctk.CTkScrollbar(self.case_list_frame, orientation="vertical", command=self.case_list.yview)
        self.case_list_scroll_y.grid(row=0, column=1, sticky="ns")

        self.case_list.configure(xscrollcommand=self.case_list_scroll_x.set, yscrollcommand=self.case_list_scroll_y.set)

        self.event_details_frame = ctk.CTkFrame(self.frame)
        self.event_details_frame.grid(row=6, column=0, columnspan=3, padx=5, pady=5, sticky="nsew")
        self.event_details_frame.grid_remove()
        
        # Make the event_details_frame expandable
        self.event_details_frame.columnconfigure(0, weight=1)
        self.event_details_frame.rowconfigure(1, weight=1)

        self.event_details_header = ctk.CTkLabel(self.event_details_frame, text="Case Events", font=("Arial", 14, "bold"))
        self.event_details_header.grid(row=0, column=0, sticky="w")

        self.event_details_text = ctk.CTkTextbox(self.event_details_frame, width=760, height=10, wrap="none", font=("Arial", 12))  # Increased width to match the table
        self.event_details_text.grid(row=1, column=0, padx=5, pady=5, sticky="nsew")

        self.event_details_scrollbar_y = ctk.CTkScrollbar(self.event_details_frame, orientation="vertical", command=self.event_details_text.yview)
        self.event_details_scrollbar_y.grid(row=1, column=1, sticky="ns")
        self.event_details_text.configure(yscrollcommand=self.event_details_scrollbar_y.set)

        self.event_details_scrollbar_x = ctk.CTkScrollbar(self.event_details_frame, orientation="horizontal", command=self.event_details_text.xview)
        self.event_details_scrollbar_x.grid(row=2, column=0, sticky="ew")
        self.event_details_text.configure(xscrollcommand=self.event_details_scrollbar_x.set)

        self.show_gantt_chart_button = ctk.CTkButton(self.frame, text="Show Gantt Chart (Selected Case)", command=self.show_gantt_chart, font=("Arial", 12))
        self.show_gantt_chart_button.grid(row=7, column=0, padx=5, pady=5, sticky="w")
        self.show_gantt_chart_button.grid_remove()  # Initially hidden
        self.show_gantt_chart_button_ttp = self.create_tooltip(self.show_gantt_chart_button, "Opens a Gantt Chart visualizing the currently selected case, alongside detected patterns.")

        self.petri_net_frame = ctk.CTkFrame(self.frame)
        self.petri_net_frame.grid(row=8, column=0, columnspan=2, padx=5, pady=5, sticky="nsew")
        self.petri_net_frame.grid_remove()
        
        # Make the petri_net_frame expandable
        self.petri_net_frame.columnconfigure(0, weight=1)
        self.petri_net_frame.rowconfigure(1, weight=1)

        self.petri_net_header = ctk.CTkLabel(self.petri_net_frame, text="Petri Net", font=("Arial", 12, "bold"))
        self.petri_net_header.grid(row=0, column=0, sticky="ew")

        self.petri_net_canvas = ctk.CTkCanvas(self.petri_net_frame)
        self.petri_net_canvas.grid(row=1, column=0, padx=5, pady=5, sticky="nsew")

        self.h_scrollbar = ctk.CTkScrollbar(self.petri_net_frame, orientation="horizontal", command=self.petri_net_canvas.xview)
        self.h_scrollbar.grid(row=2, column=0, sticky="ew")
        self.v_scrollbar = ctk.CTkScrollbar(self.petri_net_frame, orientation="vertical", command=self.petri_net_canvas.yview)
        self.v_scrollbar.grid(row=1, column=1, sticky="ns")

        self.petri_net_canvas.configure(xscrollcommand=self.h_scrollbar.set, yscrollcommand=self.v_scrollbar.set)

        self.event_log = None

    def create_tooltip(self, widget, text):
        tool_tip = ctk.CTkToplevel(widget)
        tool_tip.wm_overrideredirect(True)
        tool_tip.wm_geometry("+0+0")
        tool_tip.withdraw()
        label = ctk.CTkLabel(tool_tip, text=text, justify='left', wraplength=300)
        label.pack(ipadx=1)
        def enter(event):
            x, y, _, _ = widget.bbox("insert")
            x += widget.winfo_rootx() + 25
            y += widget.winfo_rooty() + 25
            tool_tip.wm_geometry(f"+{x}+{y}")
            tool_tip.deiconify()
        def leave(event):
            tool_tip.withdraw()
        widget.bind("<Enter>", enter)
        widget.bind("<Leave>", leave)
        return tool_tip

    def show_help(self):
        help_window = ctk.CTkToplevel(self.root)
        help_window.title("Help")
        help_text = ("Software used to identify collaborative patterns in event log.\n"
                     "Requirements in the event log (exact names):\n\n"
                     "case_id, activity, start_timestamp, end_timestamp, resource\n\n"
                     "Created by Benjamin Meier, University of Regensburg, 2024.\n"
                     "E-Mail: Benjamin_paul_meier@yahoo.de")
        help_label = ctk.CTkLabel(help_window, text=help_text, justify='left', padx=10, pady=10)
        help_label.pack(padx=10, pady=10)

    def load_event_log(self):
        # Called if GUI Button is clicked
        global file_path
        file_path = filedialog.askopenfilename(
            title="Open Event Log",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if not file_path:
            return

        try:
            # Get threshold value
            threshold_percentage = self.threshold_entry.get()
            threshold_percentage = float(threshold_percentage) if threshold_percentage.isdigit() else 30.0

            # Open event log from file
            event_log = read_event_log(file_path)
            
            # Group events by cases
            self.case_patterns = defaultdict(dict)
            self.contributing_activities = defaultdict(lambda: defaultdict(list))
            self.case_thresholds = {}

            case_events_dict = defaultdict(list)
            for event in event_log:
                case_events_dict[event['case_id']].append(event)

            # Sort cases by case_id: integer IDs numerically, do not sort non-integer Case IDs ("Case-A")
            def case_id_key(case_id):
                try:
                    return (0, int(case_id))
                except ValueError:
                    return (1, str(case_id))

            sorted_case_events_dict = dict(sorted(case_events_dict.items(), key=lambda item: case_id_key(item[0])))

            threads = []
            # Create one thread for each case (calls "process_case" method for each case)
            for case_id, case_events in sorted_case_events_dict.items():
                thread = threading.Thread(target=self.process_case, args=(case_id, case_events, threshold_percentage))
                threads.append(thread)
                thread.start()

            # Wait for all threads to finish
            for thread in threads:
                thread.join()

            self.event_log = event_log
            self.case_list.delete(*self.case_list.get_children())

            # Gather cases and patterns into a list and sort it
            sorted_cases = sorted(self.case_patterns.items(), key=lambda item: case_id_key(item[0]))
            for case_id, patterns in sorted_cases:
                pattern_names = ', '.join(set(patterns.values()))
                threshold = self.case_thresholds[case_id].total_seconds()  # Use the threshold value from the case
                self.case_list.insert("", "end", values=(case_id, f"{threshold:.2f} s", pattern_names))

            self.event_details_frame.grid_remove()
            self.petri_net_frame.grid_remove()

            # Show the view_model_button, save_button, and case_list_frame when the event log is loaded
            self.view_model_button.grid()
            self.analyze_variants_button.grid()
            self.save_button.grid()
            self.case_list_frame.grid()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def process_case(self, case_id, case_events, threshold_percentage):
        # Find patterns, save found patterns and contributing activities
        case_id, patterns, contributing_acts, threshold = find_patterns_in_case(case_id, case_events, threshold_percentage)
        self.case_patterns[case_id] = patterns
        self.contributing_activities[case_id] = contributing_acts
        self.case_thresholds[case_id] = threshold

    def on_case_select(self, event):
        # If user clicks on a single case
        selected_item = self.case_list.selection()
        if selected_item:
            case_id = self.case_list.item(selected_item[0], "values")[0]
            self.display_case_events(case_id)
            # Show the show_gantt_chart_button when a case is selected
            self.show_gantt_chart_button.grid()

    def display_case_events(self, case_id):
        case_events = [event for event in self.event_log if event['case_id'] == case_id]
        patterns = self.case_patterns[case_id]
        contributing_activities = self.contributing_activities[case_id]
        
        self.event_details_text.delete(1.0, "end")
        headers = "Case ID, Activity, Start Timestamp, End Timestamp, Resource, Pattern, Contributing Activities"
        self.event_details_text.insert("end", headers + "\n")
        self.event_details_text.insert("end", "-" * len(headers) + "\n")
        
        for event in case_events:
            pattern = patterns.get(event['activity'], "")
            contributing_acts = ', '.join(contributing_activities[event['activity']]) if pattern in ['Collaboration', 'Cooperation'] else ''
            event_details = f"{event['case_id']}, {event['activity']}, {event['start_timestamp']}, {event['end_timestamp']}, {event['resource']}, {pattern} {f'( {contributing_acts} )' if contributing_acts else ''}"
            self.event_details_text.insert("end", event_details + "\n")
        self.event_details_frame.grid()

    def generate_random_color(self):
        return "#{:06x}".format(random.randint(0, 0xFFFFFF))

    def display_petri_net(self):
        # Check if the event log is loaded
        if self.event_log is None:
            messagebox.showerror("Error", "No event log loaded.")
            return

        try:
            # Convert event log to a DataFrame
            df = pd.DataFrame(self.event_log)
            
            # Format the DataFrame for pm4py
            log = pm4py.format_dataframe(df, case_id='case_id', activity_key='activity', timestamp_key='start_timestamp')
            
            # Discover the process tree from the event log
            process_tree = pm4py.discover_process_tree_inductive(log)
            
            # Convert the process tree to a Petri net
            net, im, fm = pm4py.convert_to_petri_net(process_tree)

            # Get decorations for the Petri net visualization
            decorations = pm4py.visualization.petri_net.util.alignments_decoration.get_alignments_decoration(net, im, fm, log=log, aligned_traces=None, parameters=None)
            
            # Common color for activities performed by multiple resources
            common_color = 'green'
            
            # DataFrame to track activities and their associated resources
            dfAlreadyAdded = pd.DataFrame(columns=["activity_name", "resource"])
            
            # Dictionary to store colors for resources
            resource_colors = {}

            # Assign a random color to each unique resource
            unique_resources = df['resource'].unique()
            for resource in unique_resources:
                resource_colors[resource] = self.generate_random_color()

            # Iterate over the decorations to update labels and colors
            for key, value in decorations.items():
                if 'label' in value:
                    labelVal = value['label']
                    label_without_brackets = labelVal.split('(')[0].strip()
                    
                    # Get unique resources associated with the activity
                    resources = df[df['activity'] == label_without_brackets]['resource'].unique()
                    resources_list = ", ".join(resources)

                    # Iterate over the rows in the DataFrame
                    for index, row in df.iterrows():
                        activity_name = row['activity']
                        resourceval = row['resource']

                        # Assign colors based on resource type
                        if label_without_brackets == activity_name:
                            new_label = f"{resources_list}: {activity_name} ({value['count_move_on_model']},{value['count_fit']})"
                            value['label'] = new_label

                            # Check if the activity-resource pair is already added
                            result = dfAlreadyAdded[dfAlreadyAdded["activity_name"] == activity_name]

                            if not result.empty:
                                if not (result['resource'] == resourceval).any():
                                    value['color'] = common_color
                                    new_label = f"{resources_list}: {activity_name} ({value['count_move_on_model']},{value['count_fit']})"
                                    value['label'] = new_label
                            else:
                                value['color'] = resource_colors[resourceval]
                                new_row = {"activity_name": activity_name, "resource": resourceval}
                                dfAlreadyAdded = pd.concat([dfAlreadyAdded, pd.DataFrame([new_row])], ignore_index=True)

            # Apply decorations and visualize the Petri net
            gviz = pn_visualize.apply(net, im, fm, decorations=decorations)
            image = pn_visualizer.view(gviz)

            # Open the image file and read the image data
            with open(image, 'rb') as img_file:
                img_data = img_file.read()
                self.petri_net_image = ImageTk.PhotoImage(data=img_data)

        except Exception as e:
            # Print and display any error that occurs
            print("Error", str(e))
            messagebox.showerror("Error", str(e))

    def show_gantt_chart(self):
        # Draw Gantt chart using plotly (express)
        
        # Get the selected item from the case list
        selected_item = self.case_list.selection()
        if selected_item:
            case_id = self.case_list.item(selected_item[0], "values")[0]
            # Filter events for the selected case ID from the event log
            case_events = [event for event in self.event_log if event['case_id'] == case_id]
            df = pd.DataFrame(case_events)

            # Ensure there are valid timestamps
            df = df.dropna(subset=['start_timestamp', 'end_timestamp'])

            # Sort the DataFrame by start timestamp
            df = df.sort_values(by='start_timestamp')

            # Log the dataframe for debugging
            print(df)

            # Retrieve the threshold value for the selected case
            threshold = self.case_thresholds[case_id].total_seconds()

            # Create a Gantt chart using Plotly
            fig = px.timeline(df, x_start="start_timestamp", x_end="end_timestamp", y="activity", color="resource",
                              title=f"Gantt Chart for Case {case_id}, Threshold value = {threshold:.2f} seconds")

            # Retrieve patterns and contributing activities for the selected case
            patterns = self.case_patterns[case_id]
            contributing_activities = self.contributing_activities[case_id]

            # Adding annotations for Collaboration, Cooperation, Synchronized, and Coexistence patterns
            annotations = []
            for event in case_events:
                # Get the pattern for the current activity
                pattern = patterns.get(event['activity'], "")
                # Determine the annotation text and background color
                if pattern in ['Collaboration', 'Cooperation']:
                    contrib_acts = ', '.join(contributing_activities[event['activity']])
                    annotation_text = f"{pattern} ({contrib_acts})"
                    bgcolor = "lightblue" if pattern == 'Collaboration' else "lightgreen"
                elif pattern in ['Synchronized', 'Coexistence']:
                    annotation_text = pattern
                    bgcolor = "lightgoldenrodyellow" if pattern == 'Synchronized' else "lightcoral"
                
                # Add annotation if pattern is recognized
                if pattern in ['Collaboration', 'Cooperation', 'Synchronized', 'Coexistence']:
                    annotations.append(dict(
                        x=event['end_timestamp'],
                        y=event['activity'],
                        text=annotation_text,
                        showarrow=True,
                        arrowhead=1,
                        ax=-20,
                        ay=-40,
                        bgcolor=bgcolor
                    ))

            fig.update_layout(annotations=annotations)

            # Ensure the first activity is at the top of the chart
            sorted_activities = df['activity'].unique()
            fig.update_yaxes(categoryorder='array', categoryarray=sorted_activities)

            fig.update_layout(xaxis_title="Time", yaxis_title="Activity")
            
            # Attempt to show the figure
            try:
                fig.show()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to display Gantt chart. Error: {str(e)}")

    def save_as_csv(self):
        if not self.event_log:
            return

        file_path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        )
        if not file_path:
            return

        try:
            with open(file_path, mode='w', newline='') as file:
                writer = csv.writer(file)
                headers = ["Case ID", "Threshold", "Pattern"]
                writer.writerow(headers)
                for item in self.case_list.get_children():
                    values = self.case_list.item(item, "values")
                    writer.writerow(values)
            messagebox.showinfo("Success", "File saved successfully!")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def analyze_process_variants(self):
        # Ensure the event log is loaded
        if not self.event_log:
            return

        # Discover the process variants from the event log
        process_variants, variant_case_ids = self.discover_process_variants(self.event_log)

        # Create a new window to display the process variants
        variants_window = ctk.CTkToplevel(self.root)
        variants_window.title("Process Variants")
        variants_window.geometry("1500x800")  # Set the initial size of the window

        # Create a treeview widget to display the process variants
        tree = ttk.Treeview(variants_window, columns=("Index", "Variant", "Share (total)", "Pattern", "Percentage"), show="headings", height=20)
        tree.heading("Index", text="Index", anchor='w')
        tree.heading("Variant", text="Variant", anchor='w')
        tree.heading("Share (total)", text="Share (total)", anchor='w')
        tree.heading("Pattern", text="Pattern", anchor='w')
        tree.heading("Percentage", text="Percentage", anchor='w')
        tree.grid(row=0, column=0, sticky="nsew")

        # Add scrollbars to the treeview
        scroll_y = ctk.CTkScrollbar(variants_window, orientation="vertical", command=tree.yview)
        scroll_y.grid(row=0, column=1, sticky="ns")
        tree.configure(yscrollcommand=scroll_y.set)

        scroll_x = ctk.CTkScrollbar(variants_window, orientation="horizontal", command=tree.xview)
        scroll_x.grid(row=1, column=0, sticky="ew")
        tree.configure(xscrollcommand=scroll_x.set)

        # Configure the grid to make the treeview expandable
        variants_window.grid_rowconfigure(0, weight=1)
        variants_window.grid_columnconfigure(0, weight=1)

        # Calculate the total number of instances across all variants
        total_instances = sum(sum(details.values()) for details in process_variants.values())

        tree_data = []
        for index, (variant, details) in enumerate(process_variants.items(), start=1):
            variant_total_instances = sum(details.values())
            variant_share = (variant_total_instances / total_instances) * 100
            variant_rows = []
            for pattern, count in details.items():
                percentage = (count / variant_total_instances) * 100
                variant_rows.append((index, variant, f"{variant_share:.2f}%", pattern, percentage))
            # Sort variant rows by percentage (descending order)
            variant_rows.sort(key=lambda x: -x[4])
            tree_data.extend(variant_rows)

        # Sort tree data by share (descending order) and by percentage within each variant
        tree_data.sort(key=lambda x: (-float(x[2].strip('%')), x[0], -x[4]))

        # Renumber the indices to always start from 1
        current_index = 0
        previous_variant = None

        # Insert sorted data into the tree
        for row_data in tree_data:
            variant = row_data[1]
            if variant != previous_variant:
                current_index += 1
                previous_variant = variant
            item = tree.insert("", "end", values=(current_index, variant, row_data[2], row_data[3], f"{row_data[4]:.2f}%"))
            # Highlight the most common pattern line
            if row_data[4] == max(row[4] for row in tree_data if row[1] == row_data[1]):
                tree.item(item, tags=("highlight",))

        # Define the tag configuration for highlighting
        tree.tag_configure("highlight", background="lightblue")

        # Set column widths
        max_variant_width = int(self.root.winfo_screenwidth() * 0.4)
        for col in tree["columns"]:
            max_width = font.Font().measure(col)
            for item in tree.get_children():
                cell_value = tree.item(item)["values"][tree["columns"].index(col)]
                col_width = font.Font().measure(cell_value)
                if max_width < col_width:
                    max_width = col_width
            if col == "Variant":
                tree.column(col, width=min(max_variant_width, max_width))
            else:
                tree.column(col, width=max_width)

        # Simulate merged cells by hiding text in duplicate entries
        self.variant_rows = {}
        prev_variant = None
        for item in tree.get_children():
            current_values = tree.item(item)["values"]
            if prev_variant and prev_variant == current_values[1]:  # Check if the variant is the same as the previous one
                tree.set(item, column="Variant", value="")
                tree.set(item, column="Index", value="")
                tree.set(item, column="Share (total)", value="")
            else:
                prev_variant = current_values[1]
            self.variant_rows[item] = current_values  # Store the actual values for each row

        tree.bind("<Double-1>", lambda event: self.on_pattern_double_click(event, tree, variant_case_ids))

    def on_pattern_double_click(self, event, tree, variant_case_ids):
        selected_item = tree.selection()
        if selected_item:
            # Retrieve the actual values from the stored dictionary
            values = self.variant_rows[selected_item[0]]
            variant = values[1]
            pattern = values[3]
            self.show_cases_for_variant(variant, pattern, variant_case_ids)

    def show_cases_for_variant(self, variant, pattern, variant_case_ids):
        cases_window = ctk.CTkToplevel(self.root)
        cases_window.title(f"Cases for Variant: {variant} with Pattern: {pattern}")
        cases_window.geometry("400x400")

        # Create a treeview widget to display the cases
        tree = ttk.Treeview(cases_window, columns=("CaseID",), show="headings", height=20)
        tree.heading("CaseID", text="Case ID", anchor='w')
        tree.grid(row=0, column=0, sticky="nsew")

        # Add scrollbars to the treeview
        scroll_y = ctk.CTkScrollbar(cases_window, orientation="vertical", command=tree.yview)
        scroll_y.grid(row=0, column=1, sticky="ns")
        tree.configure(yscrollcommand=scroll_y.set)

        scroll_x = ctk.CTkScrollbar(cases_window, orientation="horizontal", command=tree.xview)
        scroll_x.grid(row=1, column=0, sticky="ew")
        tree.configure(xscrollcommand=scroll_x.set)

        # Configure the grid to make the treeview expandable
        cases_window.grid_rowconfigure(0, weight=1)
        cases_window.grid_columnconfigure(0, weight=1)

        # Insert matching cases into the tree
        for case_id in variant_case_ids[variant][pattern]:
            tree.insert("", "end", values=(case_id,))

        # Bind click event to show Gantt chart for selected case
        tree.bind("<Double-1>", lambda event: self.on_case_id_double_click(event, tree))

    def on_case_id_double_click(self, event, tree):
        selected_item = tree.selection()
        if selected_item:
            case_id = tree.item(selected_item[0], "values")[0]
            self.show_gantt_chart_for_case(case_id)

    def show_gantt_chart_for_case(self, case_id):
        # Draw Gantt chart using plotly (express)

        # Filter events for the selected case ID from the event log
        case_events = [event for event in self.event_log if event['case_id'] == case_id]
        df = pd.DataFrame(case_events)

        # Ensure there are valid timestamps
        df = df.dropna(subset=['start_timestamp', 'end_timestamp'])

        # Sort the DataFrame by start timestamp
        df = df.sort_values(by='start_timestamp')

        # Log the dataframe for debugging
        print(df)

        # Retrieve the threshold value for the selected case
        threshold = self.case_thresholds[case_id].total_seconds()

        # Create a Gantt chart using Plotly
        fig = px.timeline(df, x_start="start_timestamp", x_end="end_timestamp", y="activity", color="resource",
                          title=f"Gantt Chart for Case {case_id}, Threshold value = {threshold:.2f} seconds")

        # Retrieve patterns and contributing activities for the selected case
        patterns = self.case_patterns[case_id]
        contributing_activities = self.contributing_activities[case_id]

        # Adding annotations for Collaboration, Cooperation, Synchronized, and Coexistence patterns
        annotations = []
        for event in case_events:
            # Get the pattern for the current activity
            pattern = patterns.get(event['activity'], "")
            # Determine the annotation text and background color
            if pattern in ['Collaboration', 'Cooperation']:
                contrib_acts = ', '.join(contributing_activities[event['activity']])
                annotation_text = f"{pattern} ({contrib_acts})"
                bgcolor = "lightblue" if pattern == 'Collaboration' else "lightgreen"
            elif pattern in ['Synchronized', 'Coexistence']:
                annotation_text = pattern
                bgcolor = "lightgoldenrodyellow" if pattern == 'Synchronized' else "lightcoral"

            # Add annotation if pattern is recognized
            if pattern in ['Collaboration', 'Cooperation', 'Synchronized', 'Coexistence']:
                annotations.append(dict(
                    x=event['end_timestamp'],
                    y=event['activity'],
                    text=annotation_text,
                    showarrow=True,
                    arrowhead=1,
                    ax=-20,
                    ay=-40,
                    bgcolor=bgcolor
                ))

        fig.update_layout(annotations=annotations)

        # Ensure the first activity is at the top of the chart
        sorted_activities = df['activity'].unique()
        fig.update_yaxes(categoryorder='array', categoryarray=sorted_activities)

        fig.update_layout(xaxis_title="Time", yaxis_title="Activity")

        # Attempt to show the figure
        try:
            fig.show()
            # If issues occur when showing the Gannt Chart:
            # Comment out fig.show, and remove the # on the next line:
            #figure0.write_html('first_figure.html', auto_open=True)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to display Gantt chart. Error: {str(e)}")

    def discover_process_variants(self, event_log):
        # Dictionary to store lists of activities for each case
        self.case_variants = defaultdict(list)

        # Dictionary to key-value-store the count of each pattern for each variant and the case IDs
        variant_patterns = defaultdict(lambda: defaultdict(int))
        variant_case_ids = defaultdict(lambda: defaultdict(list))

        # Iterate over each event in the event log
        for event in event_log:
            # Append the activity of the current event to the list of activities for the corresponding case
            self.case_variants[event['case_id']].append(event['activity'])

        # Iterate over each case and its activities
        for case_id, activities in self.case_variants.items():
            # Create a variant string by joining activities with '>'
            variant = '>'.join(activities)
            # Get the patterns for the current case
            patterns = self.case_patterns[case_id].values()
            # Create a string of patterns joined by ', '
            pattern_str = ', '.join(patterns)
            # Increment the count for this pattern in the variant_patterns dictionary
            variant_patterns[variant][pattern_str] += 1
            # Store the case ID in the variant_case_ids dictionary
            variant_case_ids[variant][pattern_str].append(case_id)

        # Return the dictionaries containing variants, their pattern counts, and case IDs
        return variant_patterns, variant_case_ids

if __name__ == "__main__":
    ctk.set_appearance_mode("Light")  # Modes: "System" (default), "Dark", "Light"
    ctk.set_default_color_theme("dark-blue")  # Themes: "blue" (default), "green", "dark-blue"
    root = ctk.CTk()
    app = CollaborationPatternApp(root)
    root.mainloop()
